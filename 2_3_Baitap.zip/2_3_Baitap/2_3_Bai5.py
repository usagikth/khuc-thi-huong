R = float(input("Nhập bán kính: "))
pi = 3.14

chu_vi = 2 * pi * R
dien_tich = pi * R * R

print("Chu vi:", chu_vi)
print("Diện tích:", dien_tich)